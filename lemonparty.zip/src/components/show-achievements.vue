<template>
  <v-row dense>
    <div>
      <v-col :cols="12">
        <v-card elevation="2" width="250">
          <v-card-title class="justify-center"> Te piacess </v-card-title>
          <v-card-text class="justify-center"></v-card-text>
        </v-card>
      </v-col>
    </div>
  </v-row>
</template>

<script>
export default {
  name: "show-achievements",
  props: {
    achievements: Array,
  },
};
</script>